package sp.senai.br.combustivel;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etLitroG, etAutonomiaG, etLitroE, etAutonomiaE;
    Button btnCalcular;
    TextView tvResultado;
    ConstraintLayout clPrincipal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etLitroG = findViewById(R.id.etLitroG2);
        etAutonomiaG = findViewById(R.id.etAutonomiaG);
        etLitroE = findViewById(R.id.etLitroE);
        btnCalcular = findViewById(R.id.btnCalcular);
        etAutonomiaE = findViewById(R.id.etAutonomiaE);
        tvResultado = findViewById(R.id.tvResultado);
        clPrincipal = findViewById(R.id.clPrincipal);
    }
    public void calcular (View c) {
        float fLitroG, fLitroE, fAutonomiaG, fAutonomiaE, fResultadoG, fResultadoE;

        fLitroG = Float.parseFloat(etLitroG.getText().toString());
        fLitroE = Float.parseFloat(etLitroE.getText().toString());
        fAutonomiaG = Float.parseFloat(etAutonomiaG.getText().toString());
        fAutonomiaE = Float.parseFloat(etAutonomiaE.getText().toString());

        fResultadoG = fLitroG / fAutonomiaG;
        fResultadoE = fLitroE / fAutonomiaE;

        if (fResultadoG < fResultadoE){
            tvResultado.setText(String.valueOf("Você deve abastecer com GASOLINA. \nValor da GASOLINA: "+fResultadoG+"\nValor do ETANOL: "+fResultadoE));
            clPrincipal.setBackgroundColor(Color.parseColor("#FFFFED"));
        } else {
            tvResultado.setText(String.valueOf("Você deve abastecer com ETANOL. \nValor do ETANOL: "+fResultadoE+"\nValor da GASOLINA: "+fResultadoG));
            clPrincipal.setBackgroundColor(Color.parseColor("#FF7F7F"));
        }
    }
}